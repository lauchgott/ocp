package wbs.maps;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

public class MapUtilDemo {


        public static void main(String[] args) {

            Map<String, String> ideen =  new HashMap<>();
            ideen.put("Singer", "Animal Liberation");
            ideen.put("Heidegger","Sein und Zeit");

            Map<String, Collection<String>> inverted = new HashMap<>();
            inverted = MapUtil.invertMap(ideen);
            System.out.println(ideen);
            System.out.println(inverted);



        }


    }


